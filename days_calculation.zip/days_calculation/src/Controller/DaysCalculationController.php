<?php

/**
 * @file
 * Contains \Drupal\days_calculation\Controller\DaysCalculationController.
 */
 
//use Drupal\Core\Controller\ControllerBase;
 
$form = \Drupal::formBuilder()->getForm('Drupal\days_calculation\Form\DateInputForm');

      return array(
          '#theme' => 'input_form',
          '#my_from' => $form,
      );
      
/**
* Calculate total number of days between two dates
**/      

