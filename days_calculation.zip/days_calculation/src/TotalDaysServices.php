<?php
/**
* @file providing the service that calculate total number of days.
*
*/
namespace  Drupal\days_calculation;
class TotalDaysServices {
  
 /**
* Calculate total number of days between two dates
**/      
      
public function numberOfdays($date1, $date2, $separator){
	
	$dateToArray = explode($separator, $date1);
	$dateFromArray = explode($separator, $date2);

	
	//get days from same month and same year
	if(($dateFromArray[2] > $dateToArray[2]) && ($dateFromArray[1] == $dateToArray[1]) && ($dateFromArray[0] == $dateToArray[0])) {
		$daysfromDate = $dateFromArray[2] - $dateToArray[2];
	} 
	//get days from different month of same year 
	else if(($dateFromArray[1] > $dateToArray[1]) && ($dateFromArray[0] == $dateToArray[0])) {
		$numberOfDayInMomths = TotalMonths($dateFromArray[1], $dateToArray[1]);
		$countableDaysfromMonth = countableMonthDays($dateToArray[1], $dateToArray[2]) ;
		$daysfromDate = $numberOfDayInMomths + $countableDaysfromMonth + $dateFromArray[2];
	} 
	//get days from different months in different years 
	else if($dateFromArray[0] > $dateToArray[0]) {
		$daysfromDate = monthsinYearSpan($dateToArray, $dateFromArray);
	}
	
	// return total number of days between two dates
	return $daysfromDate;
}

/**
* Check if provided year is a leap year or not
**/  
public function isLeapYear($year){
	if($year % 4 == 0 || $year % 400 == 0 || $year % 100 == 0){
		return true;
	} else {
		return false;
	}
}

/**
* Number of days in the provided month 
**/  
 public function MonthDays($month) {
	$thiry_days_months = array (4,6,9,11);
	$thiry_one_days_months = array (1,3,5,7,8,10,12);
	
	if($month != 2) {
		if(in_array($month, $thiry_days_months)){
			return 'thirtyDays';
		} else if(in_array($month, $thiry_one_days_months)){
			return 'thirtyOneDays';
		}
	} else {
		return 'twentyEightDays';
	}
}

/**
* Number of countable days in the provided month 
**/  
public function countableMonthDays($month, $date) {

	$thiry_days_months = array (4,6,9,11);
	$thiry_one_days_months = array (1,3,5,7,8,10,12);
	
	if(in_array($month, $thiry_days_months)){
		$remainDays = 30-$date;
		
	} else if(in_array($month, $thiry_one_days_months)){
		$remainDays = 31-$date;
		
	} else {
		$remainDays = 28-$date;
		
	}
	
	return $remainDays;
}

/**
* Number of months in between the provided dates
**/ 
public function TotalMonths($monthfromStartDate, $monthfromEndDate) {

	$inbetweenMonth = $monthfromEndDate - $monthfromStartDate;

	$daysFromMonths = 0;
	
	for($i=$monthfromStartDate-1; $i>$monthfromEndDate;$i--){
		$monthsDays = MonthDays($i);
		if($monthsDays == 'thirtyDays'){
		 	$daysFromMonths = $daysFromMonths + 30;
		} else if($monthsDays == 'thirtyOneDays') {
			$daysFromMonths = $daysFromMonths + 31;
		} else {
			$daysFromMonths = $daysFromMonths + 28;
		}
	}
	

	return $daysFromMonths; 
}

/**
* Number of months in between the provided dates
**/ 
public function TotalMonthsinCurrentYear($monthfromEndDate) {


	$daysFromMonths = 0;
	
	for($i=$monthfromEndDate-1; $i>=1;$i--){
		$monthsDays = MonthDays($i);
		if($monthsDays == 'thirtyDays'){
		 	$daysFromMonths = $daysFromMonths + 30;
		} else if($monthsDays == 'thirtyOneDays') {
			$daysFromMonths = $daysFromMonths + 31;
		} else {
			$daysFromMonths = $daysFromMonths + 28;
		}
	}
	

	return $daysFromMonths; 
}


public function monthsinYearSpan($dateToArray, $dateFromArray){

	$yeargap = $dateFromArray[0] - $dateToArray[0];
	
	// get total Number of days in From year
	$numberOfDayInMomths = TotalMonthsinCurrentYear($dateFromArray[1]);
	$countableDaysfromMonth = countableMonthDays($dateToArray[1], $dateToArray[2]) ;
	$daysfromYear = $numberOfDayInMomths + $countableDaysfromMonth + $dateFromArray[2];
	
	$daysfrominBetweenYear = 0;
	// get total number of days in between years
	if($yeargap > 1) {
		$daysfrominBetweenYear = 365*($yeargap-1);
	}
	
	// get total number of days in To year
	
	$daysFromMonths = 0;
	
	for($i=$dateToArray[1]+1;$i<=12;$i++) {
		$monthsDays = MonthDays($i);
		if($monthsDays == 'thirtyDays'){
		 	$daysFromMonths = $daysFromMonths + 30;
		} else if($monthsDays == 'thirtyOneDays') {
			$daysFromMonths = $daysFromMonths + 31;
		} else {
			$daysFromMonths = $daysFromMonths + 28;
		}
	}

	$countableMonthDays = countableMonthDays($dateFromArray[1], $dateFromArray[2]);

	
	$totalDaysinToYear = $daysFromMonths + $countableMonthDays;
	
	$totalDaysinYearSpan = $daysfromYear + $daysfrominBetweenYear + $totalDaysinToYear;
	
	return $totalDaysinYearSpan;
	
}
 
 
 
 
}

