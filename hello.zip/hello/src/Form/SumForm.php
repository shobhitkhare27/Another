<?php

namespace Drupal\hello\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class SumForm extends FormBase {
/**
   * @var $account
   */
  protected $sum;

  /**
   * Class constructor.
   */
  public function __construct($sum) {
    $this->sum = $sum;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
      // Load the service required to construct this class.
      $container->get('hello.sum')
    );
  }
  
    public function getFormId() {
        return 'country_form';
    }
    
    public function buildForm(array $form, FormStateInterface $form_state) {
         $form['fieldname'] = [
              '#markup' => "Please Enter Value for Addition",
         ];
       $form['first'] = [
            '#type' => 'number',
            '#title' => $this->t('First'),
            '#description' => $this->t('Enter First Number'),
            '#required' => TRUE,
        ];
       $form['second'] = [
            '#type' => 'number',
            '#title' => $this->t('Second'),
            '#description' => $this->t('Enter Second Number'),
            '#required' => TRUE,
        ];
        $form['actions'] = [
            '#type' => 'actions',
        ];

        // Add a submit button that handles the submission of the form.
        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => $this->t('Submit'),
            '#description' => $this->t('Submit, #type = submit'),
        ];
        
        return $form;
    }
    
    public function validateForm(array &$form, FormStateInterface $form_state) {
        //parent::validateForm($form, $form_state);
      if (empty($form_state->getValue('first'))) {
        $form_state->setErrorByName('first', $this->t('First should not be Empty.'));
      }        
      if (empty($form_state->getValue('second'))) {
        $form_state->setErrorByName('second', $this->t('Second should not be Empty.'));
      }        
	  
    }
    
    public function submitForm(array &$form, FormStateInterface $form_state) {
        $first = $form_state->getValue('first');
        $second = $form_state->getValue('second');
		$sumVal = $this->sum->sumValues($first,$second);
        $message = $this->t('Sum of @first and @second is @result', array('@first' => $first, '@second' => $second, '@result' => $sumVal));
        drupal_set_message($message);

    }

}
