<?php
/**
 * @file
 * Contains \Drupal\days_calculation\Form\DateInputForm.
 */

namespace Drupal\days_calculation\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Utility\UrlHelper;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Date Input form.
 */
class DateInputForm extends FormBase {

/**
   * @var $account
   */
  protected $totalDays;

  /**
   * Class constructor.
   */
  public function __construct($totalDays) {
    $this->totalDays = $totalDays;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
      // Load the service required to construct this class.
      $container->get('totalDays')
    );
  }


  /**
   * {@inheritdoc}
   */
  public function getFormId() {
  	return 'days_calculatione_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['startDate'] = array(
      	'#type' => 'date',
	    '#title' => 'Pick the start date',
	    '#format' => 'm/d/Y',
	    '#description' => t('i.e. 09/26/2018'),
	    '#required' => TRUE
    );
   
    $form['endDate'] = array(
      	'#type' => 'date',
	    '#title' => 'Pick the end date',
	    '#format' => 'm/d/Y',
	    '#description' => t('i.e. 09/06/2018'),
	    '#required' => TRUE
    );
    
    
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Submit'),
    );
    
    $form['#theme'] = 'input_form';
    return $form;
  }
  

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
	   // Validate.
	   $startDate	= strtotime($form_state->getValue('startDate'));
	   $endDate 	= strtotime($form_state->getValue('endDate'));
	   if($startDate > $endDate) {
	   		$form_state->setErrorByName('fromDate', t('Start Date can not be smaller than than from End date'));
	   } 
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Display result.
    
   	$startDate	= $form_state->getValue('startDate');
  	$endDate 	= $form_state->getValue('endDate');
  	
  	$totalDays = $this->totalDays->numberOfdays($startDate, $endDate, '-');
  	
   	drupal_set_message("total number of days between ".$startDate." and " .$endDate." is = ".$totalDays);
   
  }
  
}

