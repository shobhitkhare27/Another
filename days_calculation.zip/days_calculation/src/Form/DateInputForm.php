<?php
/**
 * @file
 * Contains \Drupal\days_calculation\Form\DateInputForm.
 */

namespace Drupal\days_calculation\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Utility\UrlHelper;

/**
 * Date Input form.
 */
class DateInputForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
  	return 'days_calculatione_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['startDate'] = array(
      	'#type' => 'date',
	    '#title' => 'Pick the start date',
	    '#format' => 'm/d/Y',
	    '#description' => t('i.e. 09/26/2018'),
	    '#required' => TRUE
    );
   
    $form['endDate'] = array(
      	'#type' => 'date',
	    '#title' => 'Pick the end date',
	    '#format' => 'm/d/Y',
	    '#description' => t('i.e. 09/06/2018'),
	    '#required' => TRUE
    );
    
    
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Submit'),
    );
    
    $form['#theme'] = 'input_form';
    return $form;
  }
  

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
	   // Validate.
	   $startDate	= strtotime($form_state->getValue('startDate'));
	   $endDate 	= strtotime($form_state->getValue('endDate'));
	   if($startDate > $endDate) {
	   		$form_state->setErrorByName('fromDate', t('Start Date can not be smaller than than from End date'));
	   } 
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Display result.
    
   	$startDate	= $form_state->getValue('startDate');
  	$endDate 	= $form_state->getValue('endDate'); 
  	
  	$totalDays 	= numberOfdays($startDate, $endDate, '-');
  	drupal_set_message("total number of days between ".$startDate." and " .$endDate." is = ".$totalDays);
   
  }
  
}

/**
* Calculate total number of days between two dates
**/      
      
function numberOfdays($date1, $date2, $separator){
	
	$dateToArray = explode($separator, $date1);
	$dateFromArray = explode($separator, $date2);

	
	//get days from same month and same year
	if($dateFromArray[1] == $dateToArray[1]) {
		$daysfromDate = $dateFromArray[2] - $dateToArray[2];
	} 
	//get days from different month of same year 
	else if($dateFromArray[1] > $dateToArray[1]) {
		$numberOfDayInMomths = TotalMonths($dateFromArray[1], $dateToArray[1]);
		
		$countableDaysfromMonth = CountableMonthDays($dateToArray[1], $dateToArray[2]) ;
		
		$daysfromDate = $numberOfDayInMomths + $countableDaysfromMonth + $dateFromArray[2];
		
		
	} else {
		echo "there";exit;
	}
	
	// return total number of days between two dates
	return $daysfromDate;
}

/**
* Check if provided year is a leap year or not
**/  
function isLeapYear($year){
	if($year % 4 == 0 || $year % 400 == 0 || $year % 100 == 0){
		return true;
	} else {
		return false;
	}
}

/**
* Number of days in the provided month 
**/  
function MonthDays($month) {
	$thiry_days_months = array (4,6,9,11);
	$thiry_one_days_months = array (1,3,5,7,8,10,12);
	
	if($month != 2) {
		if(in_array($month, $thiry_days_months)){
			return 'thirtyDays';
		} else if(in_array($month, $thiry_one_days_months)){
			return 'thirtyOneDays';
		}
	} else {
		return 'twentyEightDays';
	}
}

/**
* Number of countable days in the provided month 
**/  
function CountableMonthDays($month, $date) {

	
	$thiry_days_months = array (4,6,9,11);
	$thiry_one_days_months = array (1,3,5,7,8,10,12);
	
	if(in_array($month, $thiry_days_months)){
		$remainDays = 30-$date;
		
	} else if(in_array($month, $thiry_one_days_months)){
		$remainDays = 31-$date;
		
	} else {
		$remainDays = 28-$date;
		
	}
	
	
	return $remainDays;
}

/**
* Number of months in between the provided dates
**/ 
function TotalMonths($monthfromStartDate, $monthfromEndDate) {

	$inbetweenMonth = $monthfromEndDate - $monthfromStartDate;

	$daysFromMonths = 0;
	
	for($i=$monthfromStartDate-1; $i>$monthfromEndDate;$i--){
		$monthsDays = MonthDays($i);
		if($monthsDays == 'thirtyDays'){
		 	$daysFromMonths = $daysFromMonths + 30;
		 	echo "<br> daysFromMonths---".$daysFromMonths;
		} else if($monthsDays == 'thirtyOneDays') {
			$daysFromMonths = $daysFromMonths + 31;
			echo "<br>---".$daysFromMonths;
		} else {
			$daysFromMonths = $daysFromMonths + 28;
			echo "<br>---".$daysFromMonths;
		}
	}
	

	return $daysFromMonths; 
}